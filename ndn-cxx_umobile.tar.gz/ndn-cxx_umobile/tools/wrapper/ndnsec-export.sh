#!@SH@

`dirname "$0"`/ndnsec export "$@"