#!@SH@

`dirname "$0"`/ndnsec get-default "$@"