#!@SH@

`dirname "$0"`/ndnsec dsk-gen "$@"