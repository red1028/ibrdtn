#!@SH@

`dirname "$0"`/ndnsec sign-req "$@"