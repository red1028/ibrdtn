#!@SH@

`dirname "$0"`/ndnsec op-tool "$@"