#!@SH@

`dirname "$0"`/ndnsec set-default "$@"