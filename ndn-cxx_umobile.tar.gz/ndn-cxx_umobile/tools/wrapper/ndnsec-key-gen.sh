#!@SH@

`dirname "$0"`/ndnsec key-gen "$@"