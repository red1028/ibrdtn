#!@SH@

#to accomodate the old command
`dirname "$0"`/ndnsec cert-install "$@"