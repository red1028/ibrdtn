#!@SH@

`dirname "$0"`/ndnsec delete "$@"