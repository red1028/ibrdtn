#!@SH@

`dirname "$0"`/ndnsec unlock-tpm "$@"