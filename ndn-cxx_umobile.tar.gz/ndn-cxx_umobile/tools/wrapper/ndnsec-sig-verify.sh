#!@SH@

`dirname "$0"`/ndnsec sig-verify "$@"