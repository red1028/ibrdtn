NFD Installation Instructions
=============================

See [`docs/INSTALL.rst`](https://github.com/named-data/NFD/blob/master/docs/INSTALL.rst)
for detailed NFD installation instructions.
