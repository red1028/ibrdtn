#!@BASH@

echo "NDN RIB Management Daemon does not need to be started separately anymore"
sleep 10
exit 0
